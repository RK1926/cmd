#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${EUID}" -eq 0 ]]; then
  echo "Run this as your normal Kali user, not with sudo."
  exit 1
fi
command -v opencode >/dev/null 2>&1 || {
  echo "OpenCode is not installed yet. Run ./install.sh first."
  exit 1
}

echo "This configures OpenCode to use Ollama Cloud via its OpenAI-compatible API."
echo "Paste a NEW Ollama API key here. Input will be hidden."
read -r -s -p "Ollama API key: " key
printf '\n'
[[ -n "$key" ]] || { echo "No key entered; leaving cloud configuration unchanged."; exit 0; }

config_dir="${XDG_CONFIG_HOME:-$HOME/.config}/opencode"
secret_dir="${XDG_CONFIG_HOME:-$HOME/.config}/ollama"
config_file="$config_dir/opencode.json"
secret_file="$secret_dir/cloud_api_key"

umask 077
mkdir -p "$config_dir" "$secret_dir"
chmod 700 "$config_dir" "$secret_dir"

# Keep the key separate from the ZIP and from the JSON config.
printf '%s' "$key" > "$secret_file"
chmod 600 "$secret_file"
unset key

# Back up any existing OpenCode config rather than silently overwriting it.
if [[ -f "$config_file" ]]; then
  cp -p "$config_file" "$config_file.backup.$(date +%Y%m%d%H%M%S)"
  echo "Existing OpenCode config backed up."
fi

# Write a dedicated config. API key is loaded from a permission-restricted file.
cat > "$config_file" <<'JSON'
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "ollama-cloud": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Ollama Cloud",
      "options": {
        "baseURL": "https://ollama.com/v1",
        "apiKey": "{file:~/.config/ollama/cloud_api_key}"
      },
      "models": {
        "glm-5.3": {
          "name": "GLM 5.3 (Ollama Cloud)"
        },
        "gpt-oss:120b": {
          "name": "GPT-OSS 120B (Ollama Cloud)"
        },
        "qwen3-coder:480b": {
          "name": "Qwen 3 Coder 480B (Ollama Cloud)"
        }
      }
    }
  },
  "model": "ollama-cloud/glm-5.3"
}
JSON
chmod 600 "$config_file"

echo
echo "Ollama Cloud credentials saved with owner-only permissions."
echo "Secret file: $secret_file"
echo "OpenCode config: $config_file"
echo "Start OpenCode with: opencode"
echo "Choose another cloud model with: opencode models"
echo
echo "Note: this config is for OpenCode's Ollama Cloud API provider."
echo "It does not create an Ollama CLI browser sign-in session for 'ollama signin'."
