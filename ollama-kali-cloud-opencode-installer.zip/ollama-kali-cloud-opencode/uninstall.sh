#!/usr/bin/env bash
set -euo pipefail
[[ "${EUID}" -ne 0 ]] || { echo "Run as normal user, not sudo."; exit 1; }
echo "This removes Ollama's service/program files."
echo "It does not remove downloaded models, Ollama account data, OpenCode, or the API key."
read -r -p "Continue? [y/N] " answer
[[ "$answer" =~ ^[Yy]$ ]] || exit 0
sudo systemctl disable --now ollama 2>/dev/null || true
sudo rm -f /etc/systemd/system/ollama.service
sudo systemctl daemon-reload
sudo rm -f /usr/local/bin/ollama /usr/bin/ollama
sudo rm -rf /usr/lib/ollama
echo "Ollama program files removed. User data and OpenCode were kept."
