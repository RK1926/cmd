#!/usr/bin/env bash
set -euo pipefail
if [[ "${EUID}" -eq 0 ]]; then
  echo "Run as your normal user, not with sudo."
  exit 1
fi
command -v ollama >/dev/null 2>&1 || { echo "Install Ollama first."; exit 1; }
sudo systemctl start ollama
ollama signin
