# Ollama + OpenCode + Ollama Cloud API setup (Kali)

## Install

Extract the ZIP, open a terminal in `ollama-kali-cloud-opencode`, then run:

```bash
chmod +x install.sh configure-cloud.sh signin.sh uninstall.sh
./install.sh
```

Do not run `install.sh` with sudo. It uses sudo only for system package/service installation.

## What it does
- Installs Ollama from the official Linux installer.
- Enables and starts the Ollama service.
- Installs OpenCode from its official installer.
- Downloads `qwen2.5:0.5b` as a lightweight local model.
- Prompts privately for a NEW Ollama API key and configures OpenCode's Ollama Cloud provider.

## API key safety
The API key is entered with hidden terminal input. It is saved separately from this ZIP at:

`~/.config/ollama/cloud_api_key`

The directory is permissioned `700`, and the key file `600` (owner only). The OpenCode config references the key file; it does not contain the key itself. Do not upload/share this file or paste the key into chats. If a key has been exposed, revoke it and create a new one in Ollama Settings > Keys.

## Important distinction
The API key configures OpenCode to call Ollama Cloud's OpenAI-compatible API at `https://ollama.com/v1`. It is not the same thing as an `ollama signin` browser session. If you want Ollama CLI cloud model access through `ollama run ...:cloud`, run `ollama signin` separately.

## OpenCode cloud models
The starter config lists `glm-5.3`, `gpt-oss:120b`, and `qwen3-coder:480b`. Availability and usage depend on your Ollama account/credits/plan. You can change the default model in `~/.config/opencode/opencode.json`.

## Useful commands

```bash
ollama run qwen2.5:0.5b
opencode
opencode models
ollama signin
systemctl status ollama
```

## Reconfigure the API key later

```bash
./configure-cloud.sh
```

This script backs up an existing OpenCode config before writing its Ollama Cloud configuration. It does not delete old backup files.

## VM note
Start with the small local model on a VM with limited guest RAM/CPU. Cloud models run remotely and are more suitable for larger coding models, but require internet access and available account usage.
