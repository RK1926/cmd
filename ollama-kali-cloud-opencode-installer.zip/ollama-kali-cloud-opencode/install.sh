#!/usr/bin/env bash
set -Eeuo pipefail

MODEL="${OLLAMA_MODEL:-qwen2.5:0.5b}"
say() { printf '\n\033[1;36m[OLLAMA-KALI]\033[0m %s\n' "$*"; }
fail() { printf '\n\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2; exit 1; }

[[ "${EUID}" -ne 0 ]] || fail "Do not run with sudo. Run ./install.sh as your normal user."
command -v sudo >/dev/null 2>&1 || fail "sudo is required."
ARCH="$(dpkg --print-architecture 2>/dev/null || true)"
case "$ARCH" in amd64|arm64) ;; *) fail "Unsupported architecture: ${ARCH:-unknown}";; esac
command -v systemctl >/dev/null 2>&1 || fail "This installer requires systemd."

say "Updating Kali and installing prerequisites..."
sudo apt-get update
sudo apt-get install -y curl ca-certificates zstd python3

say "Installing Ollama using its official installer..."
tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
curl -fsSL https://ollama.com/install.sh -o "$tmp"
sh "$tmp"

say "Starting Ollama service..."
sudo systemctl enable --now ollama
sleep 2
systemctl is-active --quiet ollama || {
  sudo systemctl --no-pager --full status ollama || true
  fail "Ollama service failed. Check: journalctl -u ollama -n 80 --no-pager"
}

say "Installing OpenCode using its official installer..."
curl -fsSL https://opencode.ai/install | bash || say "OpenCode installer returned an error; you can retry later."

say "Downloading small local starter model: $MODEL"
ollama pull "$MODEL" || say "Model download failed; retry later with: ollama pull $MODEL"

printf '\n'
say "Now configure Ollama Cloud API access for OpenCode."
if [[ -x "$(dirname "$0")/configure-cloud.sh" ]]; then
  "$(dirname "$0")/configure-cloud.sh"
else
  say "configure-cloud.sh was not found. Run it manually after extracting the package."
fi

printf '\n'
say "Installation stage finished."
printf '%s\n' \
  "Local model:       ollama run $MODEL" \
  "OpenCode:          opencode" \
  "Ollama service:    systemctl status ollama" \
  "Local API:         http://127.0.0.1:11434" \
  "Cloud provider:    ollama-cloud (configured in OpenCode if you supplied a key)"
